#!/usr/bin/env python
import socket
import sys

host = '127.0.0.1'
port = 5000

try:
    #create an AF_INET, STREAM socket (TCP)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print 'Socket Created'
    #Connect to remote server
    s.connect((host , port))
    print 'Socket Connected to ' + host + ' on ip ' + host
except socket.error, msg:
    print 'Failed to create socket. Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1]
    sys.exit();

#Send some data to remote server
message = "SRVR CON"
close_msg = "SRVR CLS"

def receive_file(file_name, s):
    with open(file_name, 'wb') as f:
        print 'file opened'
        while True:
            print('receiving data...')
            data = s.recv(1024)
            print('data=%s', (data))
            if "EOF" in data:
                print 'End of file'
                f.write(data)
                break
            # write data to a file
            f.write(data)
    f.close()
    print('Successfully get the file')

try :
    #Set the whole string
    s.send(message)

    # print out what the server sends
    reply = s.recv(1024)
    print reply

    if str(reply) == "ACK":
        while True:
            response = input("""\nOptions\n1: Get network info\n2: Get OS info\n3: List directory\n4: Packet sniffer<not available>\n5: Nmap scan\n6: Exit\nEnter option: """)
            if int(response) == 1:
                # ip = raw_input("Enter IP address range: ")
                # mesg = "SRVR NTW " + str(ip)
                # print mesg
                # s.send(mesg)

                s.send("SRVR NTW")
                reply = s.recv(1024)
                if str(reply) == "ACK":
                    receive_file('received_network_info.txt', s)
                else:
                    print "Connection broken"

            if int(response) == 2:
                s.send("SRVR OS")
                reply = s.recv(1024)
                if str(reply) == "ACK":
                    receive_file('received_os_info.txt', s)
                else:
                    print "Connection broken"

            if int(response) == 3:
                directory = str(raw_input("Enter directory: "))
                mesg = "SRVR FL " + str(directory)
                print mesg
                s.send(mesg)
                reply = s.recv(1024)
                print reply
                if str(reply) == "ACK":
                    reply = s.recv(1024)
                    print reply
                else:
                    print "Connection broken"

            if int(response) == 5:
                ip = raw_input("Enter IP address range: ")
                mesg = "SRVR NMP " + str(ip)
                print mesg
                s.send(mesg)
                # s.send("SRVR NMP")
                reply = s.recv(1024)
                if str(reply) == "ACK":
                    receive_file('received_scan.txt', s)
                else:
                    print "Connection broken"

            if int(response) == 6:
                print 'exiting'
                s.send(close_msg)
                s.close()
                break

    else:
        print "Error no respnse from server"
    print reply
except socket.error, KeyboardInterrupt:
    #Send failed
    print 'Send failed'
    sys.exit()
finally:
    s.close()

print 'End of client'
