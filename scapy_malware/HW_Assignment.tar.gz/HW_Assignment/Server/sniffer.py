from scapy.all import *

# p = sniff(iface='wlp4s0', timeout=10, count=5)
# print p.summary()

def pkt_callback(pkt):
    pkt.show() # debug statement

sniff(iface="wlp4s",
   prn=pkt_callback, filter="ip", store=0)
