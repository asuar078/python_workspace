from sys import platform as _platform
import subprocess
from scapy.all import *

command1 = 'ifconfig'
option1 = '-a'

if _platform == "linux" or _platform == "linux2":
    # linux
    print('Linux or Linux2')
elif _platform == "darwin":
    # OS X
    print('darwin')
elif _platform == "win32":
    # Windows...
    print('win32')
    command1 = 'ipconfig'

print "** Network Interfaces"
p = subprocess.Popen([command1,option1], stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
network_interface, err = p.communicate()
print(network_interface)

print "\n** Arp table"
p = subprocess.Popen(['arp', '-e'], stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
arp_table, err = p.communicate()
print(arp_table)

print "\n** Route Table"
route_table = conf.route
print(route_table)

if len(sys.argv) > 1:
    ip_range = sys.argv[1]
    print '\n** Nmap scan'
    p = subprocess.Popen(['nmap', '-sP',str(ip_range)], stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE)
    scan, err = p.communicate()
    print(scan)

with open('network.txt', 'w') as f:
    f.write("\t\t\t###### Network Interfaces ######\n")
    f.write(network_interface)
    f.write("\n\t\t\t###### ARP Table ######\n")
    f.write(arp_table)
    f.write("\n\t\t\t###### Route Table ######\n")
    f.write(str(route_table))
    if len(sys.argv) > 1:
        f.write("\n\t\t\t###### nmap scan ######\n")
        f.write(str(scan))
