#!/usr/bin/env python
import socket
import threading
from functools import partial
import subprocess as sp

bind_ip = "127.0.0.1"
bind_port = 5000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind((bind_ip,bind_port))

server.listen(5)

print "[*] Listening on %s:%d" % (bind_ip,bind_port)

def send_file(file_name, client_socket):
    with open(file_name, 'rb') as openfileobject:
        for chunk in iter(partial(openfileobject.read, 1024), ''):
            client_socket.send(chunk)
    print 'End of file'
    openfileobject.close()
    client_socket.send("EOF")

# this is our client-handling thread
def handle_client(client_socket):
    # print out what the client sends
    request = client_socket.recv(1024)
    print "[*] Received: %s" % request
    # send back a packet
    client_socket.send("ACK")

    try:
        while True:
            request = client_socket.recv(1024)
            print "[*] Received: %s" % request

            if str(request) == "SRVR NTW":
            # if "SRVR NTW" in str(request):
                print "Requesting network info"
                client_socket.send("ACK")

                extProc = sp.Popen(['python','network_info.py'])
                sp.Popen.wait(extProc) # closes the process
                send_file('network.txt', client_socket)

            if str(request) == "SRVR OS":
                print "Requesting os info"
                client_socket.send("ACK")

                extProc = sp.Popen(['python','os_flavor.py'])
                sp.Popen.wait(extProc) # closes the process
                send_file('os.txt', client_socket)

            if "SRVR FL" in str(request):
                print "Requesting file directory"
                client_socket.send("ACK")
                directory = request.split(" ")
                print directory
                print directory[2]
                p = sp.Popen(['ls', '-al',str(directory[2])], stdout=sp.PIPE,
                                                   stderr=sp.PIPE)
                scan, err = p.communicate()
                print scan
                client_socket.send(str(scan))

            if "SRVR NMP" in str(request):
                print "Requesting nmap scan"
                client_socket.send("ACK")
                ip = request.split(" ")
                print ip
                print ip[2]
                p = sp.Popen(['nmap', '-sP',str(ip[2])], stdout=sp.PIPE,
                                                   stderr=sp.PIPE)
                scan, err = p.communicate()
                with open('scan.txt', 'w') as f:
                    f.write("\n\t\t\t###### nmap scan ######\n")
                    f.write(str(scan))
                send_file('scan.txt', client_socket)

            if str(request) == "SRVR CLS":
                client_socket.close()
                print 'Closing socket'
                break

    except KeyboardInterrupt:
        print "KeyboardInterrupt"
    finally:
        # clean up
        client_socket.close()

while True:

    client,addr = server.accept()
    print "[*] Accepted connection from: %s:%d" % (addr[0],addr[1])

    # spin up our client thread to handle incoming data
    client_handler = threading.Thread(target=handle_client,args=(client,))
    client_handler.start()
