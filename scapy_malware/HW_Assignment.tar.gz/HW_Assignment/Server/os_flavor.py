import platform
import sys

# code from:
# https://github.com/hpcugent/easybuild/wiki/OS_flavor_name_version

def linux_distribution():
  try:
    return platform.linux_distribution()
  except:
    return "N/A"

with open('os.txt', 'w') as f:
    os_settings ="""
Python version: %s
dist: %s
linux_distribution: %s
system: %s
machine: %s
platform: %s
uname: %s
version: %s
mac_ver: %s
""" % (
sys.version.split('\n'),
str(platform.dist()),
linux_distribution(),
platform.system(),
platform.machine(),
platform.platform(),
platform.uname(),
platform.version(),
platform.mac_ver(),
)
    print(os_settings)
    f.write(os_settings)
f.close()
