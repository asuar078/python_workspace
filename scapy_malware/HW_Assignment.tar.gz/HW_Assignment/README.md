Requirement
=============
OS: Linux distro, recommended Kali Linux
Software: Python 2.7+, Nmap
Module: Scapy

I. Design
=============
		1. Infected computer will run server script
		2. Attacker will run client script
		3. The attacker will connect to the server
		4. After a connection is made the client send command request
		5. Server will reply with respond or file
        6. when finished client will close connection


II. Options
=============
Network (NTW)
	- List of network interfaces
	- ARP Table 
	- Route Table
    - Will return text file with results

OS (OS)
	- Current python version
	- Distribution (if linux)
	- System
	- Machine architecture
	- Platform
	- Username
	- Mac version (if mac)
    - Will return text file with results

List Directory (FL)
	- Performs ls on target pc
    - Will not return a file, result are printed out


Sniffer (SNF) <not yet supported>
	- Provide packet type

Nmap scan (NMP)
    - will perform -sP scan if nmap is installed
    - Need to provide ip range
    - Will return text file with results

III. Usage
=============
	1. From the server directory run "python server.py" or "./server.py"
	2. From the client directory run "python client.py" or "./client.py"
	3. If there are no issues connecting to server client.py will offer options
	   select any of the options provided.
	4. When finished hit option 6 to close client and disconnect from server

IV. Protocol Overview
=============

Client will send to server
SRVR CON - create connection
SRVR CLS - close connection
SRVR NTW - request network information
SRVR OS - request os information
SRVR FL - request list of directory
SRVR NMP - request result of nmap scan

Server will reply with acknowledgement if command is supported
ACK
